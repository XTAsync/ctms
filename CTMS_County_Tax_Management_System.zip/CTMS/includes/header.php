<?php
// includes/header.php
// Shared HTML header for user-facing pages
// Expects: $page_title (string), $active_nav (string)
$page_title  = $page_title  ?? 'Dashboard';
$active_nav  = $active_nav  ?? '';
$base_path   = $base_path   ?? '';  // e.g. '../' when in subdirectory
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="County Tax Management System - <?php echo COUNTY_NAME; ?>">
  <title><?php echo htmlspecialchars($page_title); ?> | CTMS - <?php echo COUNTY_NAME; ?></title>
  <link rel="stylesheet" href="<?php echo $base_path; ?>css/ctms.css">
  <!-- Font Awesome (CDN) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<!-- ── Navbar ── -->
<nav class="navbar">
  <a href="<?php echo $base_path; ?>user_dashboard.php" class="navbar-brand">
    <span>🏛️</span>
    <span><?php echo COUNTY_NAME; ?></span>
    <span class="badge-county"><?php echo SITE_ABBR; ?></span>
  </a>
  <ul class="navbar-nav">
    <li><a href="<?php echo $base_path; ?>user_dashboard.php"
           class="<?php echo ($active_nav==='dashboard')?'active':''; ?>">
      <i class="fa fa-gauge-high"></i> Dashboard</a></li>
    <li><a href="<?php echo $base_path; ?>make_payment.php"
           class="<?php echo ($active_nav==='payment')?'active':''; ?>">
      <i class="fa fa-money-bill"></i> Pay Tax</a></li>
    <li><a href="<?php echo $base_path; ?>payment_reports.php"
           class="<?php echo ($active_nav==='history')?'active':''; ?>">
      <i class="fa fa-list"></i> History</a></li>
    <div class="divider"></div>
    <li><a href="<?php echo $base_path; ?>change_password.php"
           class="<?php echo ($active_nav==='settings')?'active':''; ?>">
      <i class="fa fa-gear"></i> Settings</a></li>
    <li>
      <div class="user-badge">
        <i class="fa fa-user-circle"></i>
        <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
      </div>
    </li>
    <li><a href="<?php echo $base_path; ?>logout.php">
      <i class="fa fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</nav>

