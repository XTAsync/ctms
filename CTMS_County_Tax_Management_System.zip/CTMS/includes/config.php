<?php
// includes/config.php
// County Tax Management System - Database Configuration

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ctms_db');

define('SITE_NAME', 'County Tax Management System');
define('SITE_ABBR', 'CTMS');
define('COUNTY_NAME', 'Trans-Nzoia County');
define('ADMIN_EMAIL', 'tax@admin.com');

// Payment amounts (KES)
define('DAILY_AMOUNT',   75.00);
define('WEEKLY_AMOUNT',  225.00);
define('MONTHLY_AMOUNT', 650.00);

// Timezone
date_default_timezone_set('Africa/Nairobi');

// Database connection
$db = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$db) {
    die('<div style="font-family:Arial;padding:20px;background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;border-radius:5px;margin:20px;">
        <strong>Database Connection Error:</strong> ' . mysqli_connect_error() . '<br>
        Please ensure MySQL is running and the database <code>' . DB_NAME . '</code> exists.<br>
        Import <code>sql/ctms.sql</code> to set up the database.
    </div>');
}
mysqli_set_charset($db, 'utf8mb4');

// Session start (safe – only start if not already active)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper: sanitize input
function clean($db, $str) {
    return mysqli_real_escape_string($db, htmlspecialchars(strip_tags(trim($str))));
}

// Helper: redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Helper: format currency
function fmt_kes($amount) {
    return 'KES ' . number_format($amount, 2);
}

// Helper: check payment validity
function payment_status($valid_until) {
    if (empty($valid_until)) return 'none';
    $today = strtotime(date('m/d/Y'));
    $expiry = strtotime($valid_until);
    if ($expiry >= $today) return 'active';
    return 'expired';
}

// Helper: days remaining
function days_remaining($valid_until) {
    if (empty($valid_until)) return -999;
    $today = new DateTime(date('m/d/Y'));
    $expiry = new DateTime($valid_until);
    $diff = $today->diff($expiry);
    $days = (int)$diff->format('%R%a');
    return $days;
}
?>
