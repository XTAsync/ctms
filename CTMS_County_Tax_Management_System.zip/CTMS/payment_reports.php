<?php
// payment_reports.php
session_start();
error_reporting(0);
require_once 'includes/config.php';

if (!isset($_SESSION['id_number'])) redirect('index.php');
$id_number = $_SESSION['id_number'];

$sel = mysqli_query($db, "SELECT * FROM `users` WHERE `id_number`='$id_number' LIMIT 1");
$user = mysqli_fetch_assoc($sel);

$hist = mysqli_query($db, "SELECT * FROM `payments_report` WHERE `user_id_number`='$id_number' ORDER BY id DESC");
$total_res = mysqli_query($db, "SELECT COALESCE(SUM(amount),0) as total, COUNT(*) as cnt FROM `payments_report` WHERE `user_id_number`='$id_number'");
$totals = mysqli_fetch_assoc($total_res);

$page_title = 'Payment History';
$active_nav = 'history';
include 'includes/header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-history"></i> My Payment History</h1>
      <div class="breadcrumb"><a href="user_dashboard.php">Dashboard</a> &rsaquo; Payment History</div>
    </div>
    <button onclick="window.print()" class="btn btn-outline no-print">
      <i class="fa fa-print"></i> Print
    </button>
  </div>

  <div class="stat-cards">
    <div class="stat-card blue">
      <div>
        <div class="stat-value"><?php echo $totals['cnt']; ?></div>
        <div class="stat-label">Total Transactions</div>
      </div>
      <div class="stat-icon">📋</div>
    </div>
    <div class="stat-card green">
      <div>
        <div class="stat-value">KES <?php echo number_format($totals['total'], 0); ?></div>
        <div class="stat-label">Total Paid</div>
      </div>
      <div class="stat-icon">💰</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <span>All Transactions – <?php echo htmlspecialchars($user['username']); ?></span>
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Package</th>
              <th>Mode</th>
              <th>M-Pesa Ref</th>
              <th>Date Paid</th>
              <th>Time</th>
              <th>Valid Until</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php if (mysqli_num_rows($hist) === 0): ?>
              <tr><td colspan="9" class="text-center" style="padding:30px; color:#888;">No payment records found.</td></tr>
            <?php else: $i=1; while($row = mysqli_fetch_assoc($hist)): ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><span class="badge badge-info"><?php echo ucfirst($row['payment_type']); ?></span></td>
              <td><?php echo strtoupper($row['payment_mode']); ?></td>
              <td><code><?php echo htmlspecialchars($row['mpesa_ref'] ?: '—'); ?></code></td>
              <td><?php echo $row['date_payed']; ?></td>
              <td><?php echo $row['time_payed']; ?></td>
              <td><?php echo $row['valid_untill']; ?></td>
              <td class="fw-bold">KES <?php echo number_format($row['amount'], 2); ?></td>
              <td>
                <?php $s = payment_status($row['valid_untill']); ?>
                <span class="badge badge-<?php echo ($s==='active')?'success':'danger'; ?>">
                  <?php echo ucfirst($s); ?>
                </span>
              </td>
            </tr>
            <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
