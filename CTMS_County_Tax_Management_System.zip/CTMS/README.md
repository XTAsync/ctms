# County Tax Management System (CTMS)
## St. Joseph's Boys Senior School – Kitale, Trans-Nzoia County
**Authors:** Prescott Ochiri & Wayne Mahlon  
**Category:** Computer Science | 62nd Kenya National Secondary Students' Science & Engineering Fair  
**Year:** 2026

---

## 📋 Project Overview

The **Automated County Tax Management System (CTMS)** is a distributed software + hardware system designed to automate the collection of county cess/transit taxes from heavy commercial vehicles. It eliminates human "middlemen" at county borders by integrating RFID vehicle identification with an M-Pesa payment gateway and a servo-controlled gate.

**Core Problem Solved:** Kenyan counties lose 30–40% of potential revenue through manual loopholes, bribery, and unintegrated systems. CTMS plugs these leaks.

---

## 🗂️ Project Structure

```
CTMS/
├── index.php                  # Taxpayer login page
├── user_dashboard.php         # User dashboard & payment status
├── make_payment.php           # M-Pesa payment form
├── payment_reports.php        # User payment history
├── change_password.php        # Change password
├── update_profile.php         # Update profile info
├── logout.php
│
├── admin/
│   ├── login.php              # Admin login
│   ├── dashboard.php          # Revenue command centre
│   ├── users.php              # All taxpayers list
│   ├── register_user.php      # Register new taxpayer
│   ├── payments.php           # All payment records
│   ├── expired.php            # Expired / unpaid users
│   ├── reports.php            # Daily / weekly / monthly reports
│   ├── rfid.php               # RFID tag registration & management
│   ├── gate_logs.php          # Physical gate access logs
│   ├── logout.php
│   └── includes/
│       └── admin_header.php
│
├── api/
│   └── check_rfid.php         # ESP32 JSON API (hardware integration)
│
├── includes/
│   ├── config.php             # DB connection & helpers
│   └── header.php             # User nav header
│
├── css/
│   └── ctms.css               # Main stylesheet
│
└── sql/
    └── ctms.sql               # Database schema + seed data
```

---

## ⚙️ Setup Instructions (XAMPP)

### 1. Install XAMPP
Download from https://www.apachefriends.org and install on Windows, Mac, or Linux.

### 2. Copy project
Copy the entire `CTMS/` folder into:
```
C:\xampp\htdocs\CTMS\     (Windows)
/opt/lampp/htdocs/CTMS/   (Linux)
```

### 3. Set up the database
1. Open XAMPP Control Panel → Start **Apache** and **MySQL**
2. Open browser → http://localhost/phpmyadmin
3. Click **Import** → Choose `CTMS/sql/ctms.sql` → Click **Go**
4. Database `ctms_db` will be created automatically with sample data

### 4. Access the system
| URL | Description |
|-----|-------------|
| http://localhost/CTMS/ | Taxpayer login |
| http://localhost/CTMS/admin/login.php | Admin login |

---

## 🔑 Default Login Credentials

### Admin
| Field    | Value |
|----------|-------|
| Email    | tax@admin.com |
| Password | admin123 |

### Sample Taxpayers (password = their ID number)
| Name            | ID Number | Password  |
|-----------------|-----------|-----------|
| Peter Mason     | 35098765  | 35098765  |
| Oliver Tweesty  | 35678909  | 35678909  |
| Augustine Owuor | 36566580  | 36566580  |
| Nebster Malash  | 35781223  | 35781223  |

---

## 🔌 Hardware Integration (ESP32 + RFID)

The system provides a JSON REST API for the ESP32 microcontroller:

```
GET http://[server_ip]/CTMS/api/check_rfid.php?uid=A1B2C3D4&checkpoint=Main+Gate
```

**Response (Access Granted):**
```json
{
  "access": "granted",
  "uid": "A1B2C3D4",
  "name": "Peter Mason",
  "plate": "KBZ 001A",
  "package": "weekly",
  "valid_until": "03/14/2026",
  "message": "Welcome, Peter Mason. Gate OPEN."
}
```

**Response (Access Denied):**
```json
{
  "access": "denied",
  "uid": "A1B2C3D4",
  "message": "Access DENIED: Payment expired on 03/07/2026"
}
```

**ESP32 Logic:**
```cpp
// Pseudo-code for ESP32
if (rfid.read(&uid)) {
    String url = "http://192.168.1.100/CTMS/api/check_rfid.php?uid=" + uid;
    String response = http.GET(url);
    JSONObject json = parse(response);
    
    if (json["access"] == "granted") {
        servo.write(90);   // Open gate
        delay(5000);
        servo.write(0);    // Close gate
        greenLED.on();
    } else {
        redLED.on();
        buzzer.beep();
    }
}
```

### Hardware Components Required
| Component | Purpose |
|-----------|---------|
| ESP32 Microcontroller | Main controller |
| RC522 RFID Sensor (MFRC522) | Read RFID tags |
| SG90 Servo Motor | Physical gate control |
| RFID Cards/Tags | Vehicle identification |
| Jumper Wires | Connections |
| Breadboard | Prototyping |
| LEDs (Red & Green) | Status indicators |

---

## 💳 Payment Packages

| Package | Duration | Amount (KES) |
|---------|----------|-------------|
| Daily   | 1 day    | 75.00 |
| Weekly  | 7 days   | 225.00 |
| Monthly | 30 days  | 650.00 |

---

## 🔒 Security Features

- bcrypt password hashing (PHP `password_hash()`)
- Session-based authentication
- SQL injection prevention via `mysqli_real_escape_string()`
- Input sanitization with `htmlspecialchars()`
- Role-based access: admin vs taxpayer
- SSL-ready (deploy on HTTPS for production)

---

## 📊 Key Features

### For Taxpayers
- Secure login with ID number
- View current payment status & days remaining
- Make payments via M-Pesa, Airtel Money, or Cash
- View full payment history with digital receipts
- Update profile and change password

### For County Administrators
- Revenue command centre dashboard
- Real-time KPIs: daily revenue, active taxpayers, expired users
- Register and manage taxpayers
- View all payment records with search/filter
- Daily / Weekly / Monthly revenue reports
- Manage RFID tags and assign to vehicles
- View gate access logs (granted vs denied entries)

---

## 🌐 Technology Stack

| Layer | Technology |
|-------|-----------|
| Backend | PHP 7.4+ |
| Database | MySQL / MariaDB via XAMPP |
| Frontend | HTML5, CSS3, JavaScript |
| UI Framework | Custom CSS (no external framework required) |
| Icons | Font Awesome 6 (CDN) |
| Hardware API | RESTful JSON endpoint |
| Security | bcrypt, SSL, session auth |

---

## 📈 Research Findings (from the project)

| RAM (GB) | Processing Speed (GHz) | Update Time (sec) |
|----------|------------------------|-------------------|
| 2        | 2.6                    | 4.5               |
| 4        | 2.8                    | 3.5               |
| 6        | 2.9                    | 2.5               |
| 8        | 3.2                    | 1.5               |
| 16       | 3.4                    | **0.5**           |

**Conclusion:** Minimum recommended specs: **16 GB RAM, 3.4 GHz CPU, 50 Mbps internet** for real-time performance.

---

## 📧 Contact

- Prescott Ochiri – presscottochiri@gmail.com
- Wayne Mahlon – waynemahlon@gmail.com  
- School: St. Joseph's Boys Senior School, Kitale
- Patron: Mr. Fanuel Okata – okataf@gmail.com

---

*CTMS v2.0 · Trans-Nzoia County · Kenya · 2026*
