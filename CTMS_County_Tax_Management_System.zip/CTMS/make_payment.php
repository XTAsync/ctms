<?php
// make_payment.php
session_start();
error_reporting(0);
require_once 'includes/config.php';

if (!isset($_SESSION['id_number'])) redirect('index.php');
$id_number = $_SESSION['id_number'];

// Fetch user
$sel = mysqli_query($db, "SELECT * FROM `users` WHERE `id_number`='$id_number' LIMIT 1");
$user = mysqli_fetch_assoc($sel);

$success = $error = '';

// Payment packages
$packages = [
    'daily'   => ['label' => 'Daily',   'days' => 1,  'amount' => DAILY_AMOUNT],
    'weekly'  => ['label' => 'Weekly',  'days' => 7,  'amount' => WEEKLY_AMOUNT],
    'monthly' => ['label' => 'Monthly', 'days' => 30, 'amount' => MONTHLY_AMOUNT],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pkg_type = clean($db, $_POST['package'] ?? '');
    $pay_mode = clean($db, $_POST['payment_mode'] ?? '');
    $phone    = clean($db, $_POST['phone'] ?? $user['phone']);
    $mpesa_ref= clean($db, $_POST['mpesa_ref'] ?? '');

    if (!array_key_exists($pkg_type, $packages)) {
        $error = 'Please select a valid payment package.';
    } elseif (empty($pay_mode)) {
        $error = 'Please select a payment mode.';
    } elseif ($pay_mode === 'mpesa' && empty($mpesa_ref)) {
        $error = 'Please enter the M-Pesa transaction code.';
    } else {
        $pkg    = $packages[$pkg_type];
        $amount = $pkg['amount'];
        $days   = $pkg['days'];
        $date_paid  = date('m/d/Y');
        $time_paid  = date('h:ia');
        $valid_until= date('m/d/Y', strtotime("+{$days} days"));

        // Generate ref if not provided
        if (empty($mpesa_ref)) {
            $mpesa_ref = 'CASH' . strtoupper(substr(md5(uniqid()), 0, 8));
        }

        // Upsert into payments (current active payment)
        $existing = mysqli_query($db, "SELECT id FROM `payments` WHERE `user_id_number`='$id_number' LIMIT 1");
        if (mysqli_num_rows($existing) > 0) {
            $row = mysqli_fetch_assoc($existing);
            mysqli_query($db, "UPDATE `payments` SET
                `payment_type`='$pkg_type',
                `payment_mode`='$pay_mode',
                `date_payed`='$date_paid',
                `time_payed`='$time_paid',
                `valid_untill`='$valid_until',
                `amount`='$amount'
                WHERE `id`='{$row['id']}'");
        } else {
            mysqli_query($db, "INSERT INTO `payments`
                (`user_id_number`,`payment_type`,`payment_mode`,`date_payed`,`time_payed`,`valid_untill`,`amount`)
                VALUES ('$id_number','$pkg_type','$pay_mode','$date_paid','$time_paid','$valid_until','$amount')");
        }

        // Insert into payment history
        $uname = clean($db, $user['username']);
        mysqli_query($db, "INSERT INTO `payments_report`
            (`user_id_number`,`username`,`payment_type`,`payment_mode`,`date_payed`,`time_payed`,`valid_untill`,`amount`,`mpesa_ref`)
            VALUES ('$id_number','$uname','$pkg_type','$pay_mode','$date_paid','$time_paid','$valid_until','$amount','$mpesa_ref')");

        // Update user phone if changed
        if (!empty($phone) && $phone !== $user['phone']) {
            mysqli_query($db, "UPDATE `users` SET `phone`='$phone' WHERE `id_number`='$id_number'");
        }

        $success = "Payment successful! ✅ Your {$pkg['label']} package (KES {$pkg['amount']}) is valid until <strong>{$valid_until}</strong>. Ref: <strong>{$mpesa_ref}</strong>";
    }
}

$page_title = 'Make Payment';
$active_nav = 'payment';
include 'includes/header.php';
?>

<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-money-bill"></i> Make Tax Payment</h1>
      <div class="breadcrumb"><a href="user_dashboard.php">Dashboard</a> &rsaquo; Make Payment</div>
    </div>
  </div>

  <?php if ($success): ?>
    <div class="alert alert-success">
      <i class="fa fa-circle-check"></i> <?php echo $success; ?>
    </div>
    <!-- Simulated receipt -->
    <div class="card" style="max-width:520px; margin:0 auto 24px;">
      <div class="card-header" style="background:#1e8449;">
        <span>🧾 Payment Receipt</span>
        <button onclick="window.print()" class="btn btn-sm" style="background:rgba(255,255,255,0.2);color:#fff;">
          <i class="fa fa-print"></i> Print
        </button>
      </div>
      <div class="card-body text-center">
        <div style="font-size:48px; margin-bottom:8px;">✅</div>
        <h3 style="color:#1e8449; margin:0 0 16px;"><?php echo COUNTY_NAME; ?></h3>
        <p style="color:#888; font-size:12px; margin:0 0 16px;">County Tax Management System – Official Receipt</p>
        <div style="background:#f8fdf8; border-radius:6px; padding:16px; text-align:left;">
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #eee;">
            <span style="color:#888;">Taxpayer</span>
            <strong><?php echo htmlspecialchars($user['username']); ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #eee;">
            <span style="color:#888;">ID Number</span>
            <strong><?php echo htmlspecialchars($id_number); ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #eee;">
            <span style="color:#888;">Date</span>
            <strong><?php echo date('M j, Y g:i A'); ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #eee;">
            <span style="color:#888;">M-Pesa Ref</span>
            <strong><?php echo htmlspecialchars($_POST['mpesa_ref'] ?? ''); ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;padding:8px 0;">
            <span style="color:#888; font-size:16px;">Amount</span>
            <strong style="font-size:20px; color:#1e8449;">KES <?php echo number_format($packages[$_POST['package'] ?? 'daily']['amount'], 2); ?></strong>
          </div>
        </div>
        <a href="user_dashboard.php" class="btn btn-primary btn-block mt-2">Return to Dashboard</a>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert alert-danger">
      <i class="fa fa-circle-exclamation"></i> <?php echo $error; ?>
    </div>
  <?php endif; ?>

  <div class="two-col">

    <!-- Payment Form -->
    <div>
      <div class="card">
        <div class="card-header light">
          <span><i class="fa fa-credit-card"></i> Step 1: Select Package</span>
        </div>
        <div class="card-body">
          <div class="payment-cards" id="pkg-cards">
            <?php foreach ($packages as $key => $pkg): ?>
            <div class="payment-card" data-pkg="<?php echo $key; ?>" onclick="selectPackage(this, '<?php echo $key; ?>')">
              <div class="pkg-name"><?php echo $pkg['label']; ?></div>
              <div class="pkg-amount">KES <?php echo number_format($pkg['amount'], 0); ?></div>
              <div class="pkg-duration"><?php echo $pkg['days']; ?> day<?php echo ($pkg['days']>1)?'s':''; ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header light">
          <span><i class="fa fa-mobile-alt"></i> Step 2: Payment Details</span>
        </div>
        <div class="card-body">
          <form method="POST" action="">
            <input type="hidden" name="package" id="pkg-input" value="">

            <div class="form-group">
              <label>Payment Mode</label>
              <select name="payment_mode" id="payment_mode" class="form-control" onchange="toggleMpesa(this)">
                <option value="">-- Select Mode --</option>
                <option value="mpesa">M-Pesa</option>
                <option value="airtel_money">Airtel Money</option>
                <option value="cash">Cash</option>
              </select>
            </div>

            <div class="form-group" id="phone-group">
              <label>Phone Number (for M-Pesa / SMS receipt)</label>
              <input type="text" name="phone" class="form-control"
                     placeholder="07XXXXXXXX"
                     value="<?php echo htmlspecialchars($user['phone']); ?>">
            </div>

            <div class="form-group" id="mpesa-ref-group" style="display:none;">
              <label>M-Pesa / Transaction Code <span style="color:red">*</span></label>
              <input type="text" name="mpesa_ref" id="mpesa_ref" class="form-control"
                     placeholder="e.g. QHT7XXXXXX" style="text-transform:uppercase;">
              <small class="text-muted">
                Pay <strong>KES <span id="amount-hint">—</span></strong> to <strong>Till/Paybill 123456</strong>
                (<?php echo COUNTY_NAME; ?>) then enter the confirmation code above.
              </small>
            </div>

            <div id="summary-box" style="display:none; background:#eafaf1; border-radius:6px; padding:14px; margin-bottom:16px;">
              <strong>Payment Summary</strong><br>
              Package: <span id="sum-pkg">—</span><br>
              Amount: <strong>KES <span id="sum-amt">—</span></strong><br>
              Valid for: <span id="sum-days">—</span>
            </div>

            <button type="submit" class="btn btn-success btn-block btn-lg" id="pay-btn" disabled>
              <i class="fa fa-lock"></i> Confirm &amp; Pay
            </button>
          </form>
        </div>
      </div>
    </div>

    <!-- Info Panel -->
    <div>
      <div class="card">
        <div class="card-header light">
          <span><i class="fa fa-circle-info"></i> How to Pay via M-Pesa</span>
        </div>
        <div class="card-body">
          <ol style="padding-left:20px; line-height:2;">
            <li>Go to <strong>M-Pesa</strong> menu on your phone</li>
            <li>Select <strong>Lipa na M-Pesa</strong></li>
            <li>Select <strong>Pay Bill</strong></li>
            <li>Business No: <strong>123456</strong></li>
            <li>Account No: Your <strong>ID Number</strong></li>
            <li>Amount: as per your selected package</li>
            <li>Enter PIN and confirm</li>
            <li>Copy the <strong>M-Pesa code</strong> from SMS confirmation</li>
            <li>Paste the code in the form and submit</li>
          </ol>
          <div class="alert alert-info mt-1">
            <i class="fa fa-shield-halved"></i>
            <div>Your payment is secured with SSL encryption. Your financial details are never stored.</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header light">
          <span><i class="fa fa-tag"></i> Package Rates</span>
        </div>
        <div class="card-body" style="padding:0;">
          <table class="ctms-table">
            <thead>
              <tr><th>Package</th><th>Duration</th><th>Amount (KES)</th></tr>
            </thead>
            <tbody>
              <tr><td>Daily</td><td>1 day</td><td class="fw-bold">75.00</td></tr>
              <tr><td>Weekly</td><td>7 days</td><td class="fw-bold">225.00</td></tr>
              <tr><td>Monthly</td><td>30 days</td><td class="fw-bold">650.00</td></tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>

<script>
const pkgData = {
  daily:   { label: 'Daily',   amount: 75,  days: '1 day' },
  weekly:  { label: 'Weekly',  amount: 225, days: '7 days' },
  monthly: { label: 'Monthly', amount: 650, days: '30 days' }
};

let selectedPkg = null;

function selectPackage(el, key) {
  document.querySelectorAll('.payment-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  selectedPkg = key;
  document.getElementById('pkg-input').value = key;
  // update summary
  const p = pkgData[key];
  document.getElementById('sum-pkg').textContent  = p.label;
  document.getElementById('sum-amt').textContent  = p.amount.toFixed(2);
  document.getElementById('sum-days').textContent = p.days;
  document.getElementById('amount-hint').textContent = p.amount.toFixed(2);
  document.getElementById('summary-box').style.display = 'block';
  checkReady();
}

function toggleMpesa(sel) {
  const isMpesa = (sel.value === 'mpesa' || sel.value === 'airtel_money');
  document.getElementById('mpesa-ref-group').style.display = isMpesa ? 'block' : 'none';
  checkReady();
}

function checkReady() {
  const mode = document.getElementById('payment_mode').value;
  const ref  = document.getElementById('mpesa_ref').value.trim();
  const isMpesa = (mode === 'mpesa' || mode === 'airtel_money');
  const ready = selectedPkg && mode && (!isMpesa || ref.length >= 8);
  document.getElementById('pay-btn').disabled = !ready;
}

document.getElementById('mpesa_ref').addEventListener('input', checkReady);
document.getElementById('payment_mode').addEventListener('change', checkReady);
</script>
</body>
</html>
