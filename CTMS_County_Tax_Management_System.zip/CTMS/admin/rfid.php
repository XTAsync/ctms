<?php
// admin/rfid.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

$success = $error = '';

// Register new RFID tag
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_rfid'])) {
    $tag_uid   = clean($db, strtoupper($_POST['tag_uid']  ?? ''));
    $id_number = clean($db, $_POST['id_number'] ?? '');
    $plate     = clean($db, strtoupper($_POST['vehicle_plate'] ?? ''));
    $vtype     = clean($db, $_POST['vehicle_type'] ?? 'Heavy Commercial Truck');

    if (empty($tag_uid) || empty($id_number) || empty($plate)) {
        $error = 'Tag UID, ID Number, and Vehicle Plate are required.';
    } else {
        $chk = mysqli_query($db, "SELECT id FROM `rfid_tags` WHERE `tag_uid`='$tag_uid' LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = "Tag UID <strong>{$tag_uid}</strong> is already registered.";
        } else {
            mysqli_query($db, "INSERT INTO `rfid_tags` (`tag_uid`,`user_id_number`,`vehicle_plate`,`vehicle_type`)
                VALUES ('$tag_uid','$id_number','$plate','$vtype')");
            $success = "RFID tag <strong>{$tag_uid}</strong> registered to vehicle <strong>{$plate}</strong>.";
        }
    }
}

// Toggle tag
if (isset($_GET['toggle'])) {
    $tid = (int)$_GET['toggle'];
    mysqli_query($db, "UPDATE `rfid_tags` SET `is_active` = 1 - `is_active` WHERE `id`='$tid'");
    redirect('rfid.php');
}

$tags = mysqli_query($db, "SELECT r.*, u.username FROM `rfid_tags` r
    LEFT JOIN `users` u ON r.user_id_number = u.id_number
    ORDER BY r.id DESC");

$users = mysqli_query($db, "SELECT id_number, username FROM `users` ORDER BY username");

$page_title = 'RFID Tag Management';
$active_nav = 'rfid';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <h1><i class="fa fa-wifi"></i> RFID Tag Management</h1>
    <div class="breadcrumb">Admin &rsaquo; RFID Tags</div>
  </div>

  <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
  <?php if ($error):   ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>

  <div class="two-col">

    <div class="card">
      <div class="card-header light"><span><i class="fa fa-plus"></i> Register New RFID Tag</span></div>
      <div class="card-body">
        <form method="POST">
          <div class="form-group">
            <label>RFID Tag UID <span style="color:red">*</span></label>
            <input type="text" name="tag_uid" class="form-control" required
                   placeholder="e.g. A1B2C3D4" style="text-transform:uppercase;"
                   value="<?php echo htmlspecialchars($_POST['tag_uid'] ?? ''); ?>">
            <small class="text-muted">Read from RFID reader on the ESP32.</small>
          </div>
          <div class="form-group">
            <label>Assign to Taxpayer <span style="color:red">*</span></label>
            <select name="id_number" class="form-control" required>
              <option value="">-- Select Taxpayer --</option>
              <?php while($u = mysqli_fetch_assoc($users)): ?>
              <option value="<?php echo $u['id_number']; ?>"><?php echo htmlspecialchars($u['username']); ?> (<?php echo $u['id_number']; ?>)</option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Vehicle Plate <span style="color:red">*</span></label>
              <input type="text" name="vehicle_plate" class="form-control" required
                     placeholder="e.g. KBZ 001A" style="text-transform:uppercase;"
                     value="<?php echo htmlspecialchars($_POST['vehicle_plate'] ?? ''); ?>">
            </div>
            <div class="form-group">
              <label>Vehicle Type</label>
              <select name="vehicle_type" class="form-control">
                <option>Heavy Commercial Truck</option>
                <option>Lorry</option>
                <option>Pickup</option>
                <option>Matatu</option>
                <option>Other</option>
              </select>
            </div>
          </div>
          <input type="hidden" name="register_rfid" value="1">
          <button type="submit" class="btn btn-success btn-block">
            <i class="fa fa-wifi"></i> Register Tag
          </button>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header light"><span><i class="fa fa-circle-info"></i> How RFID Works in CTMS</span></div>
      <div class="card-body">
        <ol style="line-height:2; padding-left:18px; color:#555;">
          <li>Each heavy vehicle gets a physical <strong>RFID tag</strong></li>
          <li>At the county entry point, the driver taps the tag on the <strong>ESP32 RFID reader</strong></li>
          <li>The microcontroller reads the <strong>Tag UID</strong> and queries this database</li>
          <li>If the taxpayer has an <span class="badge badge-success">Active</span> payment, the <strong>servo gate opens</strong></li>
          <li>If payment is expired, the gate stays closed and a <span class="badge badge-danger">Denied</span> log is recorded</li>
          <li>All gate events are logged in <strong>Gate Logs</strong></li>
        </ol>
        <div class="alert alert-info mt-1">
          <i class="fa fa-microchip"></i>
          <div>ESP32 API endpoint: <code>GET /api/check_rfid.php?uid=TAG_UID</code></div>
        </div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><span>All Registered RFID Tags</span></div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table">
          <thead>
            <tr><th>#</th><th>Tag UID</th><th>Taxpayer</th><th>ID Number</th>
                <th>Vehicle Plate</th><th>Type</th><th>Registered</th><th>Status</th><th>Action</th></tr>
          </thead>
          <tbody>
            <?php $i=1; while($tag = mysqli_fetch_assoc($tags)): ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><code><?php echo htmlspecialchars($tag['tag_uid']); ?></code></td>
              <td><?php echo htmlspecialchars($tag['username'] ?: '—'); ?></td>
              <td><?php echo $tag['user_id_number']; ?></td>
              <td class="fw-bold"><?php echo htmlspecialchars($tag['vehicle_plate']); ?></td>
              <td><?php echo htmlspecialchars($tag['vehicle_type']); ?></td>
              <td><?php echo date('M j, Y', strtotime($tag['registered_at'])); ?></td>
              <td>
                <?php if ($tag['is_active']): ?>
                  <span class="badge badge-success">Active</span>
                <?php else: ?>
                  <span class="badge badge-danger">Disabled</span>
                <?php endif; ?>
              </td>
              <td>
                <a href="rfid.php?toggle=<?php echo $tag['id']; ?>"
                   class="btn btn-sm btn-<?php echo $tag['is_active']?'warning':'success'; ?>"
                   onclick="return confirm('Toggle this tag?')">
                  <?php echo $tag['is_active']?'Disable':'Enable'; ?>
                </a>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
