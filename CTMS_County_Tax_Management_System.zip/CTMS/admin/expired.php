<?php
// admin/expired.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

$today = date('m/d/Y');
$expired = mysqli_query($db, "SELECT u.username, u.id_number, u.phone, u.location,
    p.payment_type, p.valid_untill, p.amount
    FROM `users` u
    LEFT JOIN `payments` p ON u.id_number = p.user_id_number
    WHERE p.valid_untill < '$today' OR p.id IS NULL
    ORDER BY p.valid_untill ASC");

$count = mysqli_num_rows($expired);

$page_title = 'Expired / Unpaid Users';
$active_nav = 'expired';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-clock"></i> Expired / Unpaid Users</h1>
      <div class="breadcrumb">Admin &rsaquo; Expired Users</div>
    </div>
    <button onclick="window.print()" class="btn btn-outline no-print">
      <i class="fa fa-print"></i> Print Report
    </button>
  </div>

  <div class="alert alert-<?php echo ($count > 0) ? 'warning' : 'success'; ?>">
    <i class="fa fa-<?php echo ($count > 0) ? 'triangle-exclamation' : 'circle-check'; ?>"></i>
    <?php echo ($count > 0)
      ? "<strong>{$count}</strong> user(s) have expired or missing payments. Gate access is restricted for these vehicles."
      : "All registered taxpayers have valid payments. ✅"; ?>
  </div>

  <div class="card">
    <div class="card-header">
      <span>Expired / Unpaid Taxpayers (<?php echo $count; ?>)</span>
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table">
          <thead>
            <tr><th>#</th><th>Name</th><th>ID Number</th><th>Phone</th><th>Location</th>
                <th>Last Package</th><th>Expired On</th><th>Amount</th><th>Days Overdue</th></tr>
          </thead>
          <tbody>
            <?php
            mysqli_data_seek($expired, 0);
            $i = 1;
            while($row = mysqli_fetch_assoc($expired)):
              $overdue = $row['valid_untill'] ? abs(days_remaining($row['valid_untill'])) : '—';
            ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td class="fw-bold"><?php echo htmlspecialchars($row['username']); ?></td>
              <td><?php echo $row['id_number']; ?></td>
              <td><?php echo $row['phone'] ?: '—'; ?></td>
              <td><?php echo $row['location'] ?: '—'; ?></td>
              <td><?php echo $row['payment_type'] ? ucfirst($row['payment_type']) : '—'; ?></td>
              <td class="text-danger fw-bold"><?php echo $row['valid_untill'] ?: 'Never paid'; ?></td>
              <td><?php echo $row['amount'] ? 'KES '.number_format($row['amount'],2) : '—'; ?></td>
              <td><span class="badge badge-danger"><?php echo is_numeric($overdue) ? $overdue.' days' : $overdue; ?></span></td>
            </tr>
            <?php endwhile; ?>
            <?php if ($count === 0): ?>
              <tr><td colspan="9" class="text-center" style="padding:30px;color:#888;">No expired users found! 🎉</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
