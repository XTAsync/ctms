<?php
// admin/payments.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

$records = mysqli_query($db, "SELECT pr.*, u.username, u.phone FROM `payments_report` pr
    LEFT JOIN `users` u ON pr.user_id_number = u.id_number
    ORDER BY pr.id DESC");

$totals = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt, COALESCE(SUM(amount),0) as total FROM `payments_report`"));

$page_title = 'All Payments';
$active_nav = 'payments';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-money-bill"></i> All Payment Records</h1>
      <div class="breadcrumb">Admin &rsaquo; Payments</div>
    </div>
    <button onclick="window.print()" class="btn btn-outline no-print"><i class="fa fa-print"></i> Print</button>
  </div>

  <div class="stat-cards">
    <div class="stat-card blue">
      <div><div class="stat-value"><?php echo $totals['cnt']; ?></div><div class="stat-label">Total Transactions</div></div>
      <div class="stat-icon">📋</div>
    </div>
    <div class="stat-card green">
      <div><div class="stat-value">KES <?php echo number_format($totals['total'], 0); ?></div><div class="stat-label">Total Revenue</div></div>
      <div class="stat-icon">💰</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <span>All Transactions</span>
      <input type="text" id="search" placeholder="🔍 Search..." class="form-control"
             style="width:220px;background:rgba(255,255,255,0.15);border:none;color:#fff;">
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table" id="pay-table">
          <thead>
            <tr>
              <th>#</th><th>Taxpayer</th><th>ID Number</th><th>Phone</th>
              <th>Package</th><th>Mode</th><th>M-Pesa Ref</th>
              <th>Date</th><th>Valid Until</th><th>Amount</th><th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; while($row = mysqli_fetch_assoc($records)):
              $s = payment_status($row['valid_untill']);
            ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><?php echo htmlspecialchars($row['username'] ?: $row['user_id_number']); ?></td>
              <td><?php echo $row['user_id_number']; ?></td>
              <td><?php echo htmlspecialchars($row['phone'] ?: '—'); ?></td>
              <td><span class="badge badge-info"><?php echo ucfirst($row['payment_type']); ?></span></td>
              <td><?php echo strtoupper($row['payment_mode']); ?></td>
              <td><code><?php echo htmlspecialchars($row['mpesa_ref'] ?: '—'); ?></code></td>
              <td><?php echo $row['date_payed']; ?></td>
              <td><?php echo $row['valid_untill']; ?></td>
              <td class="fw-bold">KES <?php echo number_format($row['amount'],2); ?></td>
              <td>
                <span class="badge badge-<?php echo ($s==='active')?'success':'danger'; ?>">
                  <?php echo ucfirst($s); ?>
                </span>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script>
document.getElementById('search').addEventListener('input', function(){
  const q = this.value.toLowerCase();
  document.querySelectorAll('#pay-table tbody tr').forEach(r => {
    r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});
</script>
</body>
</html>
