<?php
// admin/users.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

// Handle delete
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    mysqli_query($db, "DELETE FROM `users` WHERE `id`='$del_id'");
    redirect('users.php?msg=deleted');
}

$msg = $_GET['msg'] ?? '';
$users = mysqli_query($db, "SELECT u.*, p.payment_type, p.valid_untill, p.amount
    FROM `users` u
    LEFT JOIN `payments` p ON u.id_number = p.user_id_number
    ORDER BY u.id DESC");

$page_title = 'All Taxpayers';
$active_nav = 'users';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-users"></i> Registered Taxpayers</h1>
      <div class="breadcrumb">Admin &rsaquo; Taxpayers</div>
    </div>
    <a href="register_user.php" class="btn btn-success"><i class="fa fa-user-plus"></i> Register New</a>
  </div>

  <?php if ($msg === 'deleted'): ?>
    <div class="alert alert-info"><i class="fa fa-trash"></i> User deleted successfully.</div>
  <?php endif; ?>

  <div class="card">
    <div class="card-header">
      <span>All Taxpayers</span>
      <input type="text" id="search-input" placeholder="🔍 Search..." class="form-control"
             style="width:240px; background:rgba(255,255,255,0.15); border:none; color:#fff;">
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table" id="users-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>ID Number</th>
              <th>Phone</th>
              <th>Location</th>
              <th>Package</th>
              <th>Valid Until</th>
              <th>Amount (KES)</th>
              <th>Status</th>
              <th class="no-print">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; while($user = mysqli_fetch_assoc($users)):
              $p_status = payment_status($user['valid_untill'] ?? '');
            ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></td>
              <td><?php echo htmlspecialchars($user['id_number']); ?></td>
              <td><?php echo htmlspecialchars($user['phone'] ?: '—'); ?></td>
              <td><?php echo htmlspecialchars($user['location'] ?: '—'); ?></td>
              <td>
                <?php echo $user['payment_type']
                  ? '<span class="badge badge-info">'.ucfirst($user['payment_type']).'</span>'
                  : '<span class="badge badge-none">None</span>'; ?>
              </td>
              <td><?php echo $user['valid_untill'] ?: '—'; ?></td>
              <td><?php echo $user['amount'] ? 'KES '.number_format($user['amount'],2) : '—'; ?></td>
              <td>
                <?php if ($p_status === 'active'): ?>
                  <span class="badge badge-success">Active</span>
                <?php elseif ($p_status === 'expired'): ?>
                  <span class="badge badge-danger">Expired</span>
                <?php else: ?>
                  <span class="badge badge-none">No Payment</span>
                <?php endif; ?>
              </td>
              <td class="no-print">
                <a href="user_detail.php?id=<?php echo $user['id']; ?>"
                   class="btn btn-sm btn-info" title="View">
                  <i class="fa fa-eye"></i>
                </a>
                <a href="users.php?delete=<?php echo $user['id']; ?>"
                   class="btn btn-sm btn-danger" title="Delete"
                   onclick="return confirm('Delete this user?')">
                  <i class="fa fa-trash"></i>
                </a>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
document.getElementById('search-input').addEventListener('input', function() {
  const q = this.value.toLowerCase();
  document.querySelectorAll('#users-table tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});
</script>
</body>
</html>
