<?php
// admin/gate_logs.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

$logs = mysqli_query($db, "SELECT gl.*, u.username FROM `gate_logs` gl
    LEFT JOIN `users` u ON gl.user_id_number = u.id_number
    ORDER BY gl.id DESC LIMIT 200");

$total_granted = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `gate_logs` WHERE access_status='granted'"))['n'];
$total_denied  = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `gate_logs` WHERE access_status='denied'"))['n'];

$page_title = 'Gate Access Logs';
$active_nav = 'gate';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-door-open"></i> Gate Access Logs</h1>
      <div class="breadcrumb">Admin &rsaquo; Gate Logs</div>
    </div>
    <button onclick="window.print()" class="btn btn-outline no-print"><i class="fa fa-print"></i> Print</button>
  </div>

  <div class="stat-cards">
    <div class="stat-card green">
      <div>
        <div class="stat-value"><?php echo $total_granted; ?></div>
        <div class="stat-label">Access Granted</div>
      </div>
      <div class="stat-icon">🔓</div>
    </div>
    <div class="stat-card red">
      <div>
        <div class="stat-value"><?php echo $total_denied; ?></div>
        <div class="stat-label">Access Denied</div>
      </div>
      <div class="stat-icon">🔒</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><span>Last 200 Gate Events</span></div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table">
          <thead>
            <tr><th>#</th><th>Time</th><th>RFID Tag</th><th>Taxpayer</th><th>ID Number</th>
                <th>Vehicle Plate</th><th>Checkpoint</th><th>Decision</th><th>Reason</th></tr>
          </thead>
          <tbody>
            <?php $i=1; $cnt = mysqli_num_rows($logs);
            if ($cnt === 0): ?>
              <tr><td colspan="9" class="text-center" style="padding:30px;color:#888;">
                No gate events recorded yet. Events are created when vehicles scan RFID tags at checkpoints.
              </td></tr>
            <?php else: while($row = mysqli_fetch_assoc($logs)): ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><?php echo date('M j Y, g:ia', strtotime($row['logged_at'])); ?></td>
              <td><code><?php echo htmlspecialchars($row['tag_uid']); ?></code></td>
              <td><?php echo htmlspecialchars($row['username'] ?: '—'); ?></td>
              <td><?php echo $row['user_id_number']; ?></td>
              <td class="fw-bold"><?php echo htmlspecialchars($row['vehicle_plate'] ?: '—'); ?></td>
              <td><?php echo htmlspecialchars($row['checkpoint']); ?></td>
              <td>
                <?php if ($row['access_status'] === 'granted'): ?>
                  <span class="badge badge-success">✓ Granted</span>
                <?php else: ?>
                  <span class="badge badge-danger">✗ Denied</span>
                <?php endif; ?>
              </td>
              <td class="text-muted"><?php echo htmlspecialchars($row['reason'] ?: '—'); ?></td>
            </tr>
            <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
