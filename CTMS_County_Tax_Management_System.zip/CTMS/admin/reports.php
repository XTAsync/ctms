<?php
// admin/reports.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

$filter = $_GET['filter'] ?? 'daily';
$today  = date('m/d/Y');

switch ($filter) {
    case 'weekly':
        $since = date('m/d/Y', strtotime('-7 days'));
        $label = 'Last 7 Days';
        break;
    case 'monthly':
        $since = date('m/d/Y', strtotime('-30 days'));
        $label = 'Last 30 Days';
        break;
    default:
        $since = $today;
        $label = 'Today';
        $filter = 'daily';
}

$records = mysqli_query($db, "SELECT pr.*, u.username
    FROM `payments_report` pr
    LEFT JOIN `users` u ON pr.user_id_number = u.id_number
    WHERE STR_TO_DATE(pr.date_payed, '%m/%d/%Y') >= STR_TO_DATE('$since', '%m/%d/%Y')
    ORDER BY pr.id DESC");

$summary = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt, COALESCE(SUM(amount),0) as total
    FROM `payments_report`
    WHERE STR_TO_DATE(date_payed,'%m/%d/%Y') >= STR_TO_DATE('$since','%m/%d/%Y')"));

// All-time total
$all_time = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(amount),0) as total FROM `payments_report`"))['total'];

$page_title = 'Revenue Reports';
$active_nav = 'reports';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-chart-bar"></i> Revenue Reports</h1>
      <div class="breadcrumb">Admin &rsaquo; Reports &rsaquo; <?php echo $label; ?></div>
    </div>
    <button onclick="window.print()" class="btn btn-outline no-print">
      <i class="fa fa-print"></i> Print
    </button>
  </div>

  <!-- Filter Tabs -->
  <div class="no-print" style="margin-bottom:20px; display:flex; gap:8px;">
    <a href="reports.php?filter=daily"   class="btn <?php echo ($filter==='daily')?'btn-primary':'btn-outline'; ?>">Today</a>
    <a href="reports.php?filter=weekly"  class="btn <?php echo ($filter==='weekly')?'btn-primary':'btn-outline'; ?>">Last 7 Days</a>
    <a href="reports.php?filter=monthly" class="btn <?php echo ($filter==='monthly')?'btn-primary':'btn-outline'; ?>">Last 30 Days</a>
  </div>

  <div class="stat-cards">
    <div class="stat-card green">
      <div>
        <div class="stat-value">KES <?php echo number_format($summary['total'], 0); ?></div>
        <div class="stat-label">Revenue – <?php echo $label; ?></div>
      </div>
      <div class="stat-icon">💵</div>
    </div>
    <div class="stat-card blue">
      <div>
        <div class="stat-value"><?php echo $summary['cnt']; ?></div>
        <div class="stat-label">Transactions – <?php echo $label; ?></div>
      </div>
      <div class="stat-icon">📊</div>
    </div>
    <div class="stat-card blue">
      <div>
        <div class="stat-value">KES <?php echo number_format($all_time, 0); ?></div>
        <div class="stat-label">All-Time Revenue</div>
      </div>
      <div class="stat-icon">🏦</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <span>Payment Records – <?php echo $label; ?></span>
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table">
          <thead>
            <tr>
              <th>#</th><th>Taxpayer</th><th>ID Number</th><th>Package</th>
              <th>Mode</th><th>M-Pesa Ref</th><th>Date</th><th>Time</th>
              <th>Valid Until</th><th>Amount</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; $subtotal=0;
            while($row = mysqli_fetch_assoc($records)):
              $subtotal += $row['amount'];
            ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><?php echo htmlspecialchars($row['username'] ?: $row['user_id_number']); ?></td>
              <td><?php echo $row['user_id_number']; ?></td>
              <td><span class="badge badge-info"><?php echo ucfirst($row['payment_type']); ?></span></td>
              <td><?php echo strtoupper($row['payment_mode']); ?></td>
              <td><code><?php echo htmlspecialchars($row['mpesa_ref'] ?: '—'); ?></code></td>
              <td><?php echo $row['date_payed']; ?></td>
              <td><?php echo $row['time_payed']; ?></td>
              <td><?php echo $row['valid_untill']; ?></td>
              <td class="fw-bold">KES <?php echo number_format($row['amount'],2); ?></td>
            </tr>
            <?php endwhile; ?>
            <?php if ($i === 1): ?>
              <tr><td colspan="10" class="text-center" style="padding:30px;color:#888;">No transactions found for this period.</td></tr>
            <?php else: ?>
            <tr style="background:#eafaf1; font-weight:700;">
              <td colspan="9" style="text-align:right; padding:12px 14px;">TOTAL (<?php echo $label; ?>):</td>
              <td style="padding:12px 14px;">KES <?php echo number_format($subtotal, 2); ?></td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
