<?php
// admin/includes/admin_header.php
$page_title  = $page_title  ?? 'Admin';
$active_nav  = $active_nav  ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo htmlspecialchars($page_title); ?> | Admin | <?php echo SITE_NAME; ?></title>
  <link rel="stylesheet" href="../css/ctms.css">
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    crossorigin="anonymous" referrerpolicy="no-referrer"/>
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
  <a href="dashboard.php" class="navbar-brand">
    <span>🛡️</span>
    <span><?php echo COUNTY_NAME; ?> – Admin</span>
    <span class="badge-county">Revenue Office</span>
  </a>
  <ul class="navbar-nav">
    <div class="user-badge">
      <i class="fa fa-user-shield"></i>
      <?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?>
    </div>
    <li><a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</nav>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">Main Menu</div>
  <ul>
    <li><a href="dashboard.php" class="<?php echo ($active_nav==='dashboard')?'active':''; ?>">
      <span class="icon"><i class="fa fa-gauge-high"></i></span> Dashboard</a></li>
    <li><a href="users.php" class="<?php echo ($active_nav==='users')?'active':''; ?>">
      <span class="icon"><i class="fa fa-users"></i></span> Taxpayers</a></li>
    <li><a href="register_user.php" class="<?php echo ($active_nav==='register')?'active':''; ?>">
      <span class="icon"><i class="fa fa-user-plus"></i></span> Register User</a></li>
  </ul>
  <hr class="sidebar-divider">
  <div class="sidebar-header">Payments</div>
  <ul>
    <li><a href="payments.php" class="<?php echo ($active_nav==='payments')?'active':''; ?>">
      <span class="icon"><i class="fa fa-money-bill"></i></span> All Payments</a></li>
    <li><a href="expired.php" class="<?php echo ($active_nav==='expired')?'active':''; ?>">
      <span class="icon"><i class="fa fa-clock"></i></span> Expired Users</a></li>
    <li><a href="reports.php" class="<?php echo ($active_nav==='reports')?'active':''; ?>">
      <span class="icon"><i class="fa fa-chart-bar"></i></span> Revenue Reports</a></li>
  </ul>
  <hr class="sidebar-divider">
  <div class="sidebar-header">Hardware</div>
  <ul>
    <li><a href="rfid.php" class="<?php echo ($active_nav==='rfid')?'active':''; ?>">
      <span class="icon"><i class="fa fa-wifi"></i></span> RFID Tags</a></li>
    <li><a href="gate_logs.php" class="<?php echo ($active_nav==='gate')?'active':''; ?>">
      <span class="icon"><i class="fa fa-door-open"></i></span> Gate Logs</a></li>
  </ul>
  <hr class="sidebar-divider">
  <ul>
    <li><a href="logout.php">
      <span class="icon"><i class="fa fa-sign-out-alt"></i></span> Logout</a></li>
  </ul>
</div>

