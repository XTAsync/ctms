<?php
// admin/login.php
session_start();
error_reporting(0);
require_once '../includes/config.php';

if (isset($_SESSION['admin_id'])) redirect('dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = clean($db, $_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter email and password.';
    } else {
        $sql = "SELECT * FROM `admin` WHERE `email`='$email' LIMIT 1";
        $res = mysqli_query($db, $sql);
        if ($res && mysqli_num_rows($res) === 1) {
            $admin = mysqli_fetch_assoc($res);
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id']  = $admin['id'];
                $_SESSION['admin_name']= $admin['username'];
                redirect('dashboard.php');
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'Admin account not found.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Login | <?php echo SITE_NAME; ?></title>
  <link rel="stylesheet" href="../css/ctms.css">
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    crossorigin="anonymous" referrerpolicy="no-referrer"/>
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div class="login-logo">
      <div class="logo-icon">🛡️</div>
      <h2>Admin Portal</h2>
      <p><?php echo COUNTY_NAME; ?> – Revenue Officers</p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger"><i class="fa fa-circle-exclamation"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label><i class="fa fa-envelope"></i> Admin Email</label>
        <input type="email" name="email" class="form-control"
               placeholder="tax@admin.com"
               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
      </div>
      <div class="form-group">
        <label><i class="fa fa-lock"></i> Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg">
        <i class="fa fa-shield-halved"></i> Admin Login
      </button>
    </form>
    <div class="divider"></div>
    <p class="text-center text-muted" style="font-size:12px;">
      <a href="../index.php">← Taxpayer Login</a>
    </p>
    <p class="text-center" style="font-size:11px; color:#bbb; margin-top:6px;">
      Default: tax@admin.com / admin123
    </p>
  </div>
</div>
</body>
</html>
