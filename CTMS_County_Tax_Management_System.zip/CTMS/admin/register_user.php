<?php
// admin/register_user.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username  = clean($db, $_POST['username']  ?? '');
    $id_number = clean($db, $_POST['id_number'] ?? '');
    $email     = clean($db, $_POST['email']     ?? '');
    $phone     = clean($db, $_POST['phone']     ?? '');
    $location  = clean($db, $_POST['location']  ?? '');

    if (empty($username) || empty($id_number)) {
        $error = 'Name and ID Number are required.';
    } else {
        // Check duplicate
        $chk = mysqli_query($db, "SELECT id FROM `users` WHERE `id_number`='$id_number' LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = "A user with ID Number <strong>{$id_number}</strong> already exists.";
        } else {
            // Default password = id_number
            $hash = password_hash($id_number, PASSWORD_DEFAULT);
            $q = mysqli_query($db, "INSERT INTO `users` (`username`,`email`,`password`,`location`,`id_number`,`phone`)
                VALUES ('$username','$email','$hash','$location','$id_number','$phone')");
            if ($q) {
                $success = "User <strong>{$username}</strong> (ID: {$id_number}) registered successfully. Default password is their ID number.";
            } else {
                $error = 'Database error: ' . mysqli_error($db);
            }
        }
    }
}

$page_title = 'Register User';
$active_nav = 'register';
include 'includes/admin_header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1><i class="fa fa-user-plus"></i> Register New Taxpayer</h1>
      <div class="breadcrumb">Admin &rsaquo; Register User</div>
    </div>
    <a href="users.php" class="btn btn-outline"><i class="fa fa-arrow-left"></i> All Users</a>
  </div>

  <?php if ($success): ?>
    <div class="alert alert-success"><i class="fa fa-circle-check"></i> <?php echo $success; ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fa fa-circle-exclamation"></i> <?php echo $error; ?></div>
  <?php endif; ?>

  <div class="two-col">
    <div class="card">
      <div class="card-header light"><span><i class="fa fa-id-card"></i> Taxpayer Details</span></div>
      <div class="card-body">
        <form method="POST">
          <div class="form-group">
            <label>Full Name <span style="color:red">*</span></label>
            <input type="text" name="username" class="form-control" required
                   placeholder="e.g. John Kamau"
                   value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
          </div>
          <div class="form-group">
            <label>National ID Number <span style="color:red">*</span></label>
            <input type="text" name="id_number" class="form-control" required
                   placeholder="e.g. 35098765"
                   value="<?php echo htmlspecialchars($_POST['id_number'] ?? ''); ?>">
            <small class="text-muted">This will also be the user's default password.</small>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Phone Number</label>
              <input type="text" name="phone" class="form-control"
                     placeholder="07XXXXXXXX"
                     value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
            </div>
            <div class="form-group">
              <label>Email Address</label>
              <input type="email" name="email" class="form-control"
                     placeholder="user@email.com"
                     value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
            </div>
          </div>
          <div class="form-group">
            <label>Location / Town</label>
            <input type="text" name="location" class="form-control"
                   placeholder="e.g. Kitale"
                   value="<?php echo htmlspecialchars($_POST['location'] ?? ''); ?>">
          </div>
          <button type="submit" class="btn btn-success btn-block btn-lg">
            <i class="fa fa-user-plus"></i> Register Taxpayer
          </button>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header light"><span><i class="fa fa-circle-info"></i> Registration Notes</span></div>
      <div class="card-body">
        <ul style="line-height:2.2; padding-left:18px; color:#555;">
          <li>The user's <strong>default password</strong> is their ID number</li>
          <li>Users should change their password on first login</li>
          <li>ID Number must be unique – no duplicates allowed</li>
          <li>Phone number is used for M-Pesa notifications</li>
          <li>After registration, assign an RFID tag via the RFID Tags page</li>
        </ul>
        <div class="alert alert-info mt-1">
          <i class="fa fa-shield-halved"></i>
          <div>All passwords are hashed using bcrypt encryption. Plain-text passwords are never stored.</div>
        </div>
        <a href="users.php" class="btn btn-primary btn-block mt-2">
          <i class="fa fa-users"></i> View All Registered Users
        </a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
