<?php
// admin/dashboard.php
session_start();
error_reporting(0);
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) redirect('login.php');

// Stats
$total_users   = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `users`"))['n'];
$active_today  = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `payments` WHERE `valid_untill` >= '".date('m/d/Y')."'"))['n'];
$expired_count = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `payments` WHERE `valid_untill` < '".date('m/d/Y')."'"))['n'];
$today_revenue = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(amount),0) as total FROM `payments_report` WHERE `date_payed`='".date('m/d/Y')."'"))['total'];
$total_revenue = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(amount),0) as total FROM `payments_report`"))['total'];
$total_tx      = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `payments_report`"))['n'];
$rfid_tags     = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as n FROM `rfid_tags` WHERE is_active=1"))['n'];

// Recent payments
$recent = mysqli_query($db, "SELECT pr.*, u.username FROM `payments_report` pr LEFT JOIN `users` u ON pr.user_id_number=u.id_number ORDER BY pr.id DESC LIMIT 10");

// Revenue by package
$by_pkg = mysqli_query($db, "SELECT payment_type, COUNT(*) as cnt, SUM(amount) as total FROM `payments_report` GROUP BY payment_type");

$page_title = 'Admin Dashboard';
$active_nav = 'dashboard';
include 'includes/admin_header.php';
?>

<div class="page-wrapper">
  <div class="page-header">
    <div>
      <h1>Revenue Command Centre</h1>
      <div class="breadcrumb">Admin &rsaquo; Dashboard &rsaquo; <?php echo date('l, F j Y'); ?></div>
    </div>
    <div>
      <a href="register_user.php" class="btn btn-success"><i class="fa fa-user-plus"></i> Register User</a>
      <a href="reports.php" class="btn btn-info" style="margin-left:8px;"><i class="fa fa-chart-bar"></i> Reports</a>
    </div>
  </div>

  <!-- KPI Cards -->
  <div class="stat-cards">
    <div class="stat-card blue">
      <div>
        <div class="stat-value"><?php echo $total_users; ?></div>
        <div class="stat-label">Registered Taxpayers</div>
      </div>
      <div class="stat-icon">👥</div>
    </div>
    <div class="stat-card green">
      <div>
        <div class="stat-value"><?php echo $active_today; ?></div>
        <div class="stat-label">Active Today</div>
      </div>
      <div class="stat-icon">✅</div>
    </div>
    <div class="stat-card red">
      <div>
        <div class="stat-value"><?php echo $expired_count; ?></div>
        <div class="stat-label">Expired / Unpaid</div>
      </div>
      <div class="stat-icon">⚠️</div>
    </div>
    <div class="stat-card green">
      <div>
        <div class="stat-value">KES <?php echo number_format($today_revenue, 0); ?></div>
        <div class="stat-label">Today's Revenue</div>
      </div>
      <div class="stat-icon">💵</div>
    </div>
    <div class="stat-card blue">
      <div>
        <div class="stat-value">KES <?php echo number_format($total_revenue, 0); ?></div>
        <div class="stat-label">Total Revenue Collected</div>
      </div>
      <div class="stat-icon">🏦</div>
    </div>
    <div class="stat-card orange">
      <div>
        <div class="stat-value"><?php echo $rfid_tags; ?></div>
        <div class="stat-label">Active RFID Tags</div>
      </div>
      <div class="stat-icon">📡</div>
    </div>
  </div>

  <div class="two-col">

    <!-- Revenue by Package -->
    <div class="card">
      <div class="card-header light">
        <span><i class="fa fa-chart-pie"></i> Revenue by Package</span>
        <a href="reports.php" class="btn btn-sm btn-outline">Full Report</a>
      </div>
      <div class="card-body" style="padding:0;">
        <table class="ctms-table">
          <thead>
            <tr><th>Package</th><th>Transactions</th><th>Revenue (KES)</th><th>% Share</th></tr>
          </thead>
          <tbody>
            <?php while($row = mysqli_fetch_assoc($by_pkg)):
              $pct = ($total_revenue > 0) ? round($row['total']/$total_revenue*100, 1) : 0;
            ?>
            <tr>
              <td><span class="badge badge-info"><?php echo ucfirst($row['payment_type']); ?></span></td>
              <td><?php echo $row['cnt']; ?></td>
              <td class="fw-bold"><?php echo number_format($row['total'], 2); ?></td>
              <td>
                <div style="background:#eee;border-radius:4px;height:12px;width:100%;">
                  <div style="background:var(--ctms-secondary);height:12px;width:<?php echo $pct; ?>%;border-radius:4px;"></div>
                </div>
                <small><?php echo $pct; ?>%</small>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Quick Links -->
    <div class="card">
      <div class="card-header light"><span><i class="fa fa-bolt"></i> Quick Actions</span></div>
      <div class="card-body">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
          <a href="register_user.php" class="btn btn-primary btn-block">
            <i class="fa fa-user-plus"></i> Register User
          </a>
          <a href="users.php" class="btn btn-info btn-block">
            <i class="fa fa-users"></i> View All Users
          </a>
          <a href="payments.php" class="btn btn-success btn-block">
            <i class="fa fa-money-bill"></i> Payment Records
          </a>
          <a href="expired.php" class="btn btn-danger btn-block">
            <i class="fa fa-clock"></i> Expired Users
          </a>
          <a href="rfid.php" class="btn btn-warning btn-block" style="color:#fff;">
            <i class="fa fa-wifi"></i> RFID Tags
          </a>
          <a href="gate_logs.php" class="btn btn-outline btn-block">
            <i class="fa fa-door-open"></i> Gate Logs
          </a>
        </div>
      </div>
    </div>

  </div>

  <!-- Recent Transactions -->
  <div class="card">
    <div class="card-header">
      <span><i class="fa fa-clock-rotate-left"></i> Recent Transactions</span>
      <a href="payments.php" class="btn btn-sm" style="background:rgba(255,255,255,0.15);color:#fff;">View All</a>
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <table class="ctms-table">
          <thead>
            <tr>
              <th>#</th><th>Taxpayer</th><th>ID Number</th><th>Package</th>
              <th>Mode</th><th>M-Pesa Ref</th><th>Date</th><th>Amount</th><th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; while($row = mysqli_fetch_assoc($recent)): ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><?php echo htmlspecialchars($row['username'] ?: $row['user_id_number']); ?></td>
              <td><?php echo $row['user_id_number']; ?></td>
              <td><span class="badge badge-info"><?php echo ucfirst($row['payment_type']); ?></span></td>
              <td><?php echo strtoupper($row['payment_mode']); ?></td>
              <td><code><?php echo htmlspecialchars($row['mpesa_ref'] ?: '—'); ?></code></td>
              <td><?php echo $row['date_payed']; ?></td>
              <td class="fw-bold">KES <?php echo number_format($row['amount'],2); ?></td>
              <td>
                <?php $s = payment_status($row['valid_untill']); ?>
                <span class="badge badge-<?php echo ($s==='active')?'success':'danger'; ?>">
                  <?php echo ucfirst($s); ?>
                </span>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
</body>
</html>
