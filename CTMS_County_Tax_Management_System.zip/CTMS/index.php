<?php
// index.php - Taxpayer Login
session_start();
error_reporting(0);

require_once 'includes/config.php';

// Already logged in → redirect
if (isset($_SESSION['id_number'])) {
    redirect('user_dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_number = clean($db, $_POST['id_number'] ?? '');
    $password  = $_POST['password'] ?? '';

    if (empty($id_number) || empty($password)) {
        $error = 'Please enter your ID number and password.';
    } else {
        $sql = "SELECT * FROM `users` WHERE `id_number` = '$id_number' LIMIT 1";
        $res = mysqli_query($db, $sql);
        if ($res && mysqli_num_rows($res) === 1) {
            $user = mysqli_fetch_assoc($res);
            if (password_verify($password, $user['password'])) {
                $_SESSION['id_number'] = $user['id_number'];
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['username']  = $user['username'];
                $_SESSION['email']     = $user['email'];
                redirect('user_dashboard.php');
            } else {
                $error = 'Invalid ID number or password.';
            }
        } else {
            $error = 'No account found with that ID number.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Taxpayer Login | <?php echo SITE_NAME; ?></title>
  <link rel="stylesheet" href="css/ctms.css">
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    crossorigin="anonymous" referrerpolicy="no-referrer"/>
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div class="login-logo">
      <div class="logo-icon">🏛️</div>
      <h2><?php echo SITE_NAME; ?></h2>
      <p><?php echo COUNTY_NAME; ?> – Taxpayer Portal</p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger">
        <i class="fa fa-circle-exclamation"></i> <?php echo $error; ?>
        <span class="alert-close" onclick="this.parentElement.remove()">×</span>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="form-group">
        <label for="id_number"><i class="fa fa-id-card"></i> National ID Number</label>
        <input type="text" id="id_number" name="id_number"
               class="form-control" placeholder="e.g. 35098765"
               value="<?php echo htmlspecialchars($_POST['id_number'] ?? ''); ?>" required>
      </div>
      <div class="form-group">
        <label for="password"><i class="fa fa-lock"></i> Password</label>
        <input type="password" id="password" name="password"
               class="form-control" placeholder="Enter your password" required>
        <small class="text-muted">First login: use your ID number as password.</small>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg">
        <i class="fa fa-sign-in-alt"></i> Login
      </button>
    </form>

    <div class="divider"></div>
    <p class="text-center text-muted" style="font-size:12px;">
      County revenue officers: <a href="admin/login.php">Admin Login →</a>
    </p>
    <p class="text-center" style="font-size:11px; color:#bbb; margin-top:8px;">
      Powered by CTMS v2.0 · <?php echo COUNTY_NAME; ?> · <?php echo date('Y'); ?>
    </p>
  </div>
</div>
</body>
</html>
