<?php
/**
 * api/check_rfid.php
 * County Tax Management System – RFID Hardware API
 *
 * Called by ESP32 microcontroller when a vehicle taps RFID tag.
 * Returns JSON so the ESP32 can decide to open/close the servo gate.
 *
 * Usage:  GET /api/check_rfid.php?uid=A1B2C3D4&checkpoint=Main+Gate
 *         POST /api/check_rfid.php  body: { "uid": "A1B2C3D4", "checkpoint": "Sub-Gate 1" }
 *
 * Response (JSON):
 *   { "access": "granted"|"denied", "name": "...", "plate": "...",
 *     "package": "...", "valid_until": "...", "message": "..." }
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');  // Allow ESP32 on LAN

error_reporting(0);
require_once '../includes/config.php';

// Accept GET or POST
$uid        = trim(strtoupper($_GET['uid']        ?? $_POST['uid']        ?? ''));
$checkpoint = trim($_GET['checkpoint'] ?? $_POST['checkpoint'] ?? 'Main Gate');

if (empty($uid)) {
    http_response_code(400);
    echo json_encode(['error' => 'uid parameter is required']);
    exit();
}

$uid = mysqli_real_escape_string($db, $uid);
$checkpoint = mysqli_real_escape_string($db, $checkpoint);
$today = date('m/d/Y');

// Lookup tag
$tag_res = mysqli_query($db, "SELECT r.*, u.username, u.id_number
    FROM `rfid_tags` r
    LEFT JOIN `users` u ON r.user_id_number = u.id_number
    WHERE r.tag_uid = '$uid' AND r.is_active = 1
    LIMIT 1");

if (!$tag_res || mysqli_num_rows($tag_res) === 0) {
    // Unknown or disabled tag
    mysqli_query($db, "INSERT INTO `gate_logs`
        (`tag_uid`,`user_id_number`,`vehicle_plate`,`checkpoint`,`access_status`,`reason`)
        VALUES ('$uid','UNKNOWN','','$checkpoint','denied','Tag not registered or disabled')");

    echo json_encode([
        'access'     => 'denied',
        'uid'        => $uid,
        'name'       => 'Unknown',
        'plate'      => '',
        'package'    => null,
        'valid_until'=> null,
        'message'    => 'RFID tag not registered or disabled.'
    ]);
    exit();
}

$tag  = mysqli_fetch_assoc($tag_res);
$id_number   = $tag['id_number'];
$vehicle_plate = $tag['vehicle_plate'];
$owner_name  = $tag['username'] ?? 'Unknown';

// Check payment
$pay_res = mysqli_query($db, "SELECT * FROM `payments`
    WHERE `user_id_number` = '$id_number'
    ORDER BY id DESC LIMIT 1");
$payment = mysqli_fetch_assoc($pay_res);

$access = 'denied';
$reason = 'No valid payment found';

if ($payment) {
    $status = payment_status($payment['valid_untill']);
    if ($status === 'active') {
        $access = 'granted';
        $reason = 'Payment active';
    } else {
        $reason = 'Payment expired on ' . $payment['valid_untill'];
    }
}

// Log the gate event
$owner_esc = mysqli_real_escape_string($db, $id_number);
$plate_esc  = mysqli_real_escape_string($db, $vehicle_plate);
$reason_esc = mysqli_real_escape_string($db, $reason);
mysqli_query($db, "INSERT INTO `gate_logs`
    (`tag_uid`,`user_id_number`,`vehicle_plate`,`checkpoint`,`access_status`,`reason`)
    VALUES ('$uid','$owner_esc','$plate_esc','$checkpoint','$access','$reason_esc')");

// Build response
echo json_encode([
    'access'      => $access,
    'uid'         => $uid,
    'name'        => $owner_name,
    'plate'       => $vehicle_plate,
    'package'     => $payment['payment_type']  ?? null,
    'valid_until' => $payment['valid_untill']   ?? null,
    'amount'      => $payment['amount']         ?? null,
    'message'     => ($access === 'granted')
                       ? "Welcome, {$owner_name}. Gate OPEN."
                       : "Access DENIED: {$reason}"
]);
