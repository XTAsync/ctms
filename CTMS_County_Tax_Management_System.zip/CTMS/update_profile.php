<?php
// update_profile.php
session_start();
error_reporting(0);
require_once 'includes/config.php';
if (!isset($_SESSION['id_number'])) redirect('index.php');
$id_number = $_SESSION['id_number'];

$sel = mysqli_query($db, "SELECT * FROM `users` WHERE `id_number`='$id_number' LIMIT 1");
$user = mysqli_fetch_assoc($sel);
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($db, $_POST['username'] ?? '');
    $email    = clean($db, $_POST['email']    ?? '');
    $phone    = clean($db, $_POST['phone']    ?? '');
    $location = clean($db, $_POST['location'] ?? '');
    if (empty($username)) {
        $error = 'Name is required.';
    } else {
        mysqli_query($db, "UPDATE `users` SET `username`='$username',`email`='$email',`phone`='$phone',`location`='$location' WHERE `id_number`='$id_number'");
        $_SESSION['username'] = $username;
        $success = 'Profile updated successfully.';
        $user['username'] = $username; $user['email'] = $email; $user['phone'] = $phone; $user['location'] = $location;
    }
}

$page_title = 'Edit Profile';
$active_nav = 'settings';
include 'includes/header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <h1><i class="fa fa-user-pen"></i> Edit Profile</h1>
    <div class="breadcrumb"><a href="user_dashboard.php">Dashboard</a> &rsaquo; Edit Profile</div>
  </div>
  <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
  <?php if ($error):   ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
  <div class="card" style="max-width:520px;">
    <div class="card-header light"><span>Update Your Details</span></div>
    <div class="card-body">
      <form method="POST">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="username" class="form-control" required value="<?php echo htmlspecialchars($user['username']); ?>">
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>">
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>">
        </div>
        <div class="form-group">
          <label>Location / Town</label>
          <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($user['location']); ?>">
        </div>
        <div class="form-group">
          <label>ID Number (cannot change)</label>
          <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['id_number']); ?>" disabled>
        </div>
        <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-save"></i> Save Changes</button>
      </form>
    </div>
  </div>
</div>
</body></html>
