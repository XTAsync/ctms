<?php
// change_password.php
session_start();
error_reporting(0);
require_once 'includes/config.php';
if (!isset($_SESSION['id_number'])) redirect('index.php');
$id_number = $_SESSION['id_number'];

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current  = $_POST['current_password'] ?? '';
    $new_pass = $_POST['new_password']     ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    $sel = mysqli_query($db, "SELECT * FROM `users` WHERE `id_number`='$id_number' LIMIT 1");
    $user = mysqli_fetch_assoc($sel);

    if (!password_verify($current, $user['password'])) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new_pass) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($new_pass !== $confirm) {
        $error = 'New passwords do not match.';
    } else {
        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        mysqli_query($db, "UPDATE `users` SET `password`='$hash' WHERE `id_number`='$id_number'");
        $success = 'Password updated successfully!';
    }
}

$page_title = 'Change Password';
$active_nav = 'settings';
include 'includes/header.php';
?>
<div class="page-wrapper">
  <div class="page-header">
    <h1><i class="fa fa-key"></i> Change Password</h1>
    <div class="breadcrumb"><a href="user_dashboard.php">Dashboard</a> &rsaquo; Settings &rsaquo; Change Password</div>
  </div>
  <?php if ($success): ?>
    <div class="alert alert-success"><i class="fa fa-check"></i> <?php echo $success; ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fa fa-circle-exclamation"></i> <?php echo $error; ?></div>
  <?php endif; ?>
  <div class="card" style="max-width:480px;">
    <div class="card-header light"><span><i class="fa fa-lock"></i> Update Password</span></div>
    <div class="card-body">
      <form method="POST">
        <div class="form-group">
          <label>Current Password</label>
          <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="form-group">
          <label>New Password</label>
          <input type="password" name="new_password" class="form-control" required minlength="6">
        </div>
        <div class="form-group">
          <label>Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">
          <i class="fa fa-save"></i> Update Password
        </button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
