-- County Tax Management System (CTMS) Database
-- St. Joseph's Boys Senior School - Kitale, Trans-Nzoia County
-- Authors: Prescott Ochiri & Wayne Mahlon

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET NAMES utf8mb4 */;

-- Create database
CREATE DATABASE IF NOT EXISTS `ctms_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ctms_db`;

-- --------------------------------------------------------
-- Table: admin
-- --------------------------------------------------------
CREATE TABLE `admin` (
  `id`       INT(11)      NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `email`    VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin: password = "admin123"
INSERT INTO `admin` (`username`, `email`, `password`) VALUES
('admin', 'tax@admin.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(100) NOT NULL,
  `email`      VARCHAR(150) NOT NULL,
  `password`   VARCHAR(255) NOT NULL,
  `location`   VARCHAR(200) NOT NULL DEFAULT '',
  `id_number`  VARCHAR(20)  NOT NULL UNIQUE,
  `phone`      VARCHAR(20)  NOT NULL DEFAULT '',
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample users (password = their id_number)
INSERT INTO `users` (`username`, `email`, `password`, `location`, `id_number`, `phone`) VALUES
('Peter Mason',     'masonpita@gmail.com',        '$2y$10$TKh8H1.PJy.At7EjXW/WsOWx5Wh0F6/uJHVR4UF6VCPa8wnC1PXO2', 'Kitale',  '35098765', '0712345678'),
('Oliver Tweesty',  'olivertweesty32@gmail.com',  '$2y$10$TKh8H1.PJy.At7EjXW/WsOWx5Wh0F6/uJHVR4UF6VCPa8wnC1PXO2', 'Kitale',  '35678909', '0723456789'),
('Augustine Owuor', 'augustinetreezy@gmail.com',  '$2y$10$TKh8H1.PJy.At7EjXW/WsOWx5Wh0F6/uJHVR4UF6VCPa8wnC1PXO2', 'Eldoret', '36566580', '0734567890'),
('Nebster Malash',  'trizzletimberlake@gmail.com','$2y$10$TKh8H1.PJy.At7EjXW/WsOWx5Wh0F6/uJHVR4UF6VCPa8wnC1PXO2', 'Kitale',  '35781223', '0789564251'),
('John Doe',        'johndoe@gmail.com',          '$2y$10$TKh8H1.PJy.At7EjXW/WsOWx5Wh0F6/uJHVR4UF6VCPa8wnC1PXO2', 'Webuye',  '36568945', '0715977451');

-- --------------------------------------------------------
-- Table: payments (current active payment per user)
-- --------------------------------------------------------
CREATE TABLE `payments` (
  `id`              INT(11)      NOT NULL AUTO_INCREMENT,
  `user_id_number`  VARCHAR(20)  NOT NULL,
  `payment_type`    VARCHAR(50)  NOT NULL COMMENT 'daily|weekly|monthly',
  `payment_mode`    VARCHAR(50)  NOT NULL COMMENT 'mpesa|airtel_money|cash',
  `date_payed`      VARCHAR(50)  NOT NULL,
  `time_payed`      VARCHAR(50)  NOT NULL,
  `valid_untill`    VARCHAR(50)  NOT NULL,
  `amount`          DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: payments_report (full payment history)
-- --------------------------------------------------------
CREATE TABLE `payments_report` (
  `id`              INT(11)       NOT NULL AUTO_INCREMENT,
  `user_id_number`  VARCHAR(20)   NOT NULL,
  `username`        VARCHAR(100)  NOT NULL DEFAULT '',
  `payment_type`    VARCHAR(50)   NOT NULL,
  `payment_mode`    VARCHAR(50)   NOT NULL,
  `date_payed`      VARCHAR(50)   NOT NULL,
  `time_payed`      VARCHAR(50)   NOT NULL,
  `valid_untill`    VARCHAR(50)   NOT NULL,
  `amount`          DECIMAL(10,2) NOT NULL,
  `mpesa_ref`       VARCHAR(50)   NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample historical payment data
INSERT INTO `payments_report` (`user_id_number`,`username`,`payment_type`,`payment_mode`,`date_payed`,`time_payed`,`valid_untill`,`amount`,`mpesa_ref`) VALUES
('35098765','Peter Mason',    'monthly','mpesa','02/18/2024','02:44pm','02/28/2024',610.00,'MPE001'),
('35098765','Peter Mason',    'daily',  'mpesa','02/18/2024','03:37pm','02/19/2024',150.00,'MPE002'),
('35098765','Peter Mason',    'weekly', 'mpesa','02/18/2024','04:03pm','02/25/2024',360.00,'MPE003'),
('35678909','Oliver Tweesty', 'daily',  'mpesa','02/18/2024','06:19pm','02/19/2024', 60.00,'MPE004'),
('35678909','Oliver Tweesty', 'monthly','mpesa','02/18/2024','08:20pm','02/28/2024',650.00,'MPE005'),
('36566580','Augustine Owuor','daily',  'mpesa','02/18/2024','08:22pm','02/19/2024', 70.00,'MPE006'),
('35781223','Nebster Malash', 'monthly','mpesa','02/18/2024','09:34pm','02/28/2024',510.00,'MPE007'),
('35781223','Nebster Malash', 'weekly', 'mpesa','02/19/2024','08:03am','02/26/2024',225.00,'MPE008'),
('35781223','Nebster Malash', 'monthly','mpesa','02/19/2024','08:24am','02/28/2024',1100.00,'MPE009');

-- Active current payments
INSERT INTO `payments` (`user_id_number`,`payment_type`,`payment_mode`,`date_payed`,`time_payed`,`valid_untill`,`amount`) VALUES
('35098765','weekly', 'mpesa', DATE_FORMAT(NOW(),'%m/%d/%Y'), DATE_FORMAT(NOW(),'%h:%i%p'), DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 7 DAY),'%m/%d/%Y'), 225.00),
('35678909','monthly','mpesa', DATE_FORMAT(NOW(),'%m/%d/%Y'), DATE_FORMAT(NOW(),'%h:%i%p'), DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 30 DAY),'%m/%d/%Y'),650.00),
('36566580','daily',  'mpesa', DATE_FORMAT(NOW(),'%m/%d/%Y'), DATE_FORMAT(NOW(),'%h:%i%p'), DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 1 DAY),'%m/%d/%Y'), 70.00),
('35781223','monthly','mpesa', DATE_FORMAT(NOW(),'%m/%d/%Y'), DATE_FORMAT(NOW(),'%h:%i%p'), DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 30 DAY),'%m/%d/%Y'),780.00);

-- --------------------------------------------------------
-- Table: rfid_tags (RFID hardware integration)
-- --------------------------------------------------------
CREATE TABLE `rfid_tags` (
  `id`            INT(11)     NOT NULL AUTO_INCREMENT,
  `tag_uid`       VARCHAR(50) NOT NULL UNIQUE COMMENT 'Physical RFID UID',
  `user_id_number`VARCHAR(20) NOT NULL,
  `vehicle_plate` VARCHAR(20) NOT NULL,
  `vehicle_type`  VARCHAR(50) NOT NULL DEFAULT 'Heavy Commercial',
  `registered_at` TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active`     TINYINT(1)  NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `rfid_tags` (`tag_uid`,`user_id_number`,`vehicle_plate`,`vehicle_type`) VALUES
('A1B2C3D4','35098765','KBZ 001A','Heavy Commercial Truck'),
('E5F6G7H8','35678909','KCA 123B','Heavy Commercial Truck'),
('I9J0K1L2','36566580','KDA 456C','Lorry'),
('M3N4O5P6','35781223','KDB 789D','Heavy Commercial Truck');

-- --------------------------------------------------------
-- Table: gate_logs (physical gate access log)
-- --------------------------------------------------------
CREATE TABLE `gate_logs` (
  `id`            INT(11)     NOT NULL AUTO_INCREMENT,
  `tag_uid`       VARCHAR(50) NOT NULL,
  `user_id_number`VARCHAR(20) NOT NULL,
  `vehicle_plate` VARCHAR(20) NOT NULL DEFAULT '',
  `checkpoint`    VARCHAR(100)NOT NULL DEFAULT 'Main Gate',
  `access_status` ENUM('granted','denied') NOT NULL,
  `reason`        VARCHAR(200)NOT NULL DEFAULT '',
  `logged_at`     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: payment_packages (configurable rates)
-- --------------------------------------------------------
CREATE TABLE `payment_packages` (
  `id`        INT(11)       NOT NULL AUTO_INCREMENT,
  `name`      VARCHAR(50)   NOT NULL,
  `duration`  INT(11)       NOT NULL COMMENT 'days',
  `amount`    DECIMAL(10,2) NOT NULL,
  `is_active` TINYINT(1)    NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `payment_packages` (`name`,`duration`,`amount`) VALUES
('Daily',   1,   75.00),
('Weekly',  7,  225.00),
('Monthly', 30, 650.00);

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
