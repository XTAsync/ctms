<?php
// user_dashboard.php
session_start();
error_reporting(0);
require_once 'includes/config.php';

if (!isset($_SESSION['id_number'])) redirect('index.php');

$id_number = $_SESSION['id_number'];

// Fetch user info
$sel = mysqli_query($db, "SELECT * FROM `users` WHERE `id_number`='$id_number' LIMIT 1");
$user = mysqli_fetch_assoc($sel);

// Fetch latest active payment
$sel2 = mysqli_query($db, "SELECT * FROM `payments` WHERE `user_id_number`='$id_number' ORDER BY id DESC LIMIT 1");
$payment = mysqli_fetch_assoc($sel2);

// Payment status
$p_status = payment_status($payment['valid_untill'] ?? '');
$days_left = days_remaining($payment['valid_untill'] ?? '');

// Count total payments
$count_res = mysqli_query($db, "SELECT COUNT(*) as cnt, COALESCE(SUM(amount),0) as total FROM `payments_report` WHERE `user_id_number`='$id_number'");
$count_row = mysqli_fetch_assoc($count_res);

$page_title = 'My Dashboard';
$active_nav = 'dashboard';
include 'includes/header.php';
?>

<div class="page-wrapper">

  <!-- Page Header -->
  <div class="page-header">
    <div>
      <h1>Welcome, <?php echo htmlspecialchars($user['username']); ?> 👋</h1>
      <div class="breadcrumb">Dashboard &rsaquo; Overview</div>
    </div>
    <a href="make_payment.php" class="btn btn-success">
      <i class="fa fa-plus"></i> Make Payment
    </a>
  </div>

  <!-- Payment Status Alert -->
  <?php if ($p_status === 'none'): ?>
    <div class="alert alert-warning">
      <i class="fa fa-triangle-exclamation"></i>
      <strong>No active payment found.</strong> Please make a payment to keep your vehicle authorised at all checkpoints.
    </div>
  <?php elseif ($p_status === 'expired'): ?>
    <div class="alert alert-danger">
      <i class="fa fa-circle-xmark"></i>
      <strong>Your payment has expired</strong> <?php echo abs($days_left); ?> day(s) ago.
      <a href="make_payment.php" class="btn btn-sm btn-danger" style="margin-left:10px;">Renew Now</a>
    </div>
  <?php elseif ($days_left === 1): ?>
    <div class="alert alert-warning">
      <i class="fa fa-clock"></i>
      Your payment expires <strong>today</strong>. Please renew to avoid disruption.
      <a href="make_payment.php" class="btn btn-sm btn-warning" style="margin-left:10px;">Renew</a>
    </div>
  <?php elseif ($days_left <= 3 && $days_left > 0): ?>
    <div class="alert alert-warning">
      <i class="fa fa-clock"></i>
      Your payment expires in <strong><?php echo $days_left; ?> day(s)</strong>.
    </div>
  <?php endif; ?>

  <!-- Stat Cards -->
  <div class="stat-cards">
    <div class="stat-card <?php echo ($p_status==='active')?'green':'red'; ?>">
      <div>
        <div class="stat-value">
          <?php echo ($p_status==='active') ? '<span style="color:#1e8449">✓ Active</span>' : '<span style="color:#c0392b">✗ Inactive</span>'; ?>
        </div>
        <div class="stat-label">Payment Status</div>
      </div>
      <div class="stat-icon"><?php echo ($p_status==='active')? '✅':'❌'; ?></div>
    </div>
    <div class="stat-card orange">
      <div>
        <div class="stat-value"><?php echo ($days_left > 0) ? $days_left : 0; ?></div>
        <div class="stat-label">Days Remaining</div>
      </div>
      <div class="stat-icon">📅</div>
    </div>
    <div class="stat-card blue">
      <div>
        <div class="stat-value"><?php echo $count_row['cnt']; ?></div>
        <div class="stat-label">Total Payments Made</div>
      </div>
      <div class="stat-icon">💳</div>
    </div>
    <div class="stat-card green">
      <div>
        <div class="stat-value">KES <?php echo number_format($count_row['total'], 0); ?></div>
        <div class="stat-label">Total Amount Paid</div>
      </div>
      <div class="stat-icon">💰</div>
    </div>
  </div>

  <div class="two-col">

    <!-- User Info Card -->
    <div class="card">
      <div class="card-header light">
        <span><i class="fa fa-user"></i> My Account Information</span>
        <a href="update_profile.php" class="btn btn-sm btn-outline">Edit</a>
      </div>
      <div class="card-body">
        <table style="width:100%; border-collapse:collapse; font-size:14px;">
          <tr>
            <td style="padding:8px 0; color:#888; width:140px;">Full Name</td>
            <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
          </tr>
          <tr>
            <td style="padding:8px 0; color:#888;">Email</td>
            <td><?php echo htmlspecialchars($user['email'] ?: '—'); ?></td>
          </tr>
          <tr>
            <td style="padding:8px 0; color:#888;">ID Number</td>
            <td><?php echo htmlspecialchars($user['id_number']); ?></td>
          </tr>
          <tr>
            <td style="padding:8px 0; color:#888;">Phone</td>
            <td><?php echo htmlspecialchars($user['phone'] ?: '—'); ?></td>
          </tr>
          <tr>
            <td style="padding:8px 0; color:#888;">Location</td>
            <td><?php echo htmlspecialchars($user['location'] ?: '—'); ?></td>
          </tr>
          <tr>
            <td style="padding:8px 0; color:#888;">Member Since</td>
            <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
          </tr>
        </table>
      </div>
    </div>

    <!-- Current Payment Card -->
    <div class="card">
      <div class="card-header light">
        <span><i class="fa fa-receipt"></i> Current Payment Details</span>
        <a href="payment_reports.php" class="btn btn-sm btn-outline">Full History</a>
      </div>
      <div class="card-body">
        <?php if ($payment): ?>
        <div style="text-align:center; margin-bottom:16px;">
          <div class="gate-indicator <?php echo ($p_status==='active')?'gate-open':'gate-closed'; ?>">
            <?php echo ($p_status==='active') ? '🔓' : '🔒'; ?>
          </div>
          <div class="fw-bold" style="font-size:16px;">
            Gate Access: <?php echo ($p_status==='active') ? '<span class="text-success">OPEN</span>' : '<span class="text-danger">RESTRICTED</span>'; ?>
          </div>
        </div>
        <table style="width:100%; border-collapse:collapse; font-size:14px;">
          <tr>
            <td style="padding:7px 0; color:#888; width:130px;">Package</td>
            <td><span class="badge badge-info"><?php echo ucfirst($payment['payment_type']); ?></span></td>
          </tr>
          <tr>
            <td style="padding:7px 0; color:#888;">Payment Mode</td>
            <td><?php echo strtoupper($payment['payment_mode']); ?></td>
          </tr>
          <tr>
            <td style="padding:7px 0; color:#888;">Amount Paid</td>
            <td class="fw-bold text-success"><?php echo fmt_kes($payment['amount']); ?></td>
          </tr>
          <tr>
            <td style="padding:7px 0; color:#888;">Date Paid</td>
            <td><?php echo $payment['date_payed']; ?></td>
          </tr>
          <tr>
            <td style="padding:7px 0; color:#888;">Valid Until</td>
            <td class="fw-bold <?php echo ($p_status==='active')?'text-success':'text-danger'; ?>">
              <?php echo $payment['valid_untill']; ?>
            </td>
          </tr>
          <tr>
            <td style="padding:7px 0; color:#888;">Status</td>
            <td>
              <?php if ($p_status === 'active'): ?>
                <span class="badge badge-success">Active</span>
              <?php elseif ($p_status === 'expired'): ?>
                <span class="badge badge-danger">Expired</span>
              <?php else: ?>
                <span class="badge badge-none">None</span>
              <?php endif; ?>
            </td>
          </tr>
        </table>
        <?php else: ?>
          <div class="text-center" style="padding:30px 0; color:#888;">
            <div style="font-size:40px; margin-bottom:10px;">💳</div>
            <p>No payment records found.</p>
            <a href="make_payment.php" class="btn btn-primary">Make Your First Payment</a>
          </div>
        <?php endif; ?>
      </div>
    </div>

  </div>

  <!-- Recent Transactions -->
  <div class="card">
    <div class="card-header">
      <span><i class="fa fa-history"></i> Recent Transactions</span>
      <a href="payment_reports.php" class="btn btn-sm" style="background:rgba(255,255,255,0.15);color:#fff;">View All</a>
    </div>
    <div class="card-body" style="padding:0;">
      <div class="table-responsive">
        <?php
        $hist = mysqli_query($db, "SELECT * FROM `payments_report` WHERE `user_id_number`='$id_number' ORDER BY id DESC LIMIT 8");
        if (mysqli_num_rows($hist) > 0):
        ?>
        <table class="ctms-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Package</th>
              <th>Mode</th>
              <th>M-Pesa Ref</th>
              <th>Date Paid</th>
              <th>Valid Until</th>
              <th>Amount (KES)</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; while($row = mysqli_fetch_assoc($hist)): ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td><span class="badge badge-info"><?php echo ucfirst($row['payment_type']); ?></span></td>
              <td><?php echo strtoupper($row['payment_mode']); ?></td>
              <td><code><?php echo htmlspecialchars($row['mpesa_ref'] ?: '—'); ?></code></td>
              <td><?php echo $row['date_payed']; ?></td>
              <td><?php echo $row['valid_untill']; ?></td>
              <td class="fw-bold"><?php echo number_format($row['amount'], 2); ?></td>
              <td>
                <?php $s = payment_status($row['valid_untill']); ?>
                <span class="badge badge-<?php echo ($s==='active')?'success':'danger'; ?>">
                  <?php echo ucfirst($s); ?>
                </span>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
        <?php else: ?>
          <div class="text-center" style="padding:30px; color:#888;">No transactions yet.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

</div><!-- .page-wrapper -->

<script>
// Auto-dismiss alerts after 6s
document.querySelectorAll('.alert').forEach(el => {
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, 6000);
  el.style.transition = 'opacity 0.4s';
});
</script>
</body>
</html>
